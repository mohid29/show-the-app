<?php $__env->startSection('title'); ?>
Single Todo: <?php echo e($todo->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-center my-5">
  <?php echo e($todo->name); ?>

</h1>

<div class="row justify-content-center">
  <div class="col-md-6">
    <div class="card card-default">
      <div class="card-header">
        Details
      </div>

      <div class="card-body">
        <?php echo e($todo->description); ?>

      </div>
    </div>
    <a href="/todos/<?php echo e($todo->id); ?>/edit" class="btn btn-info my-2">Edit</a>
    <a href="/todos/<?php echo e($todo->id); ?>/delete" class="btn btn-danger my-2">Delete</a>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>